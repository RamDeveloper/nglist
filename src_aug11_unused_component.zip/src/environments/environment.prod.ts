export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBgZdBYp9cszfUnuQ7g25NPie6M7DkMSuA",
    authDomain: "ngdotolist.firebaseapp.com",
    databaseURL: "https://ngdotolist.firebaseio.com",
    projectId: "ngdotolist",
    storageBucket: "ngdotolist.appspot.com",
    messagingSenderId: "228810119253"
  }
};
