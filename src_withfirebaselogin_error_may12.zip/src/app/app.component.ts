import { Component } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
//Import auth service
import { AuthService } from './auth/auth.service';
//Import router
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Tours';
  token : string;
  constructor( private router:Router,private authService: AuthService,private firebasedb: AngularFireDatabase){

  }

    //Logout method
    onLogout(){
      this.authService.logout();
    }
    //Check use is logged in
    checkUserLoggedIn(){
      return localStorage.getItem('isLoggedIn') ? true : false;
    }

}
