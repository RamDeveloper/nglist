import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
//Import router
import { Router } from '@angular/router';
//import angular fire auth
import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase/app';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AuthService {

  constructor(private authService: AuthService,private router: Router, private firebaseAuth: AngularFireAuth) { }

  signUp(email: string, password: string){
    this.firebaseAuth.auth.createUserWithEmailAndPassword(email, password)
      .then(
        response => {
          console.log("Successfull Sign up");
        },
        error => console.log(error)
      )
  }
  signIn(email: string, password: string){
    this.firebaseAuth.auth.signInWithEmailAndPassword(email, password)
    .then(
      response => {   
              this.router.navigate(['home']);
              this.getCurrentUserToken(); 
              
            },
      error => console.log(error)
    );
  }
  logout(){
    this.firebaseAuth.auth.signOut();
    localStorage.removeItem('isLoggedIn');
  }
  getCurrentUserToken(){
    this.firebaseAuth.auth.currentUser.getToken()
    .then(
      (token: string) => {
        localStorage.setItem('isLoggedIn', token);
      }
    )
    localStorage.getItem('isLoggedIn');
  }
  isAuthenticated(){
    return (localStorage.getItem('isLoggedIn')) ? true : false;
  }
}
